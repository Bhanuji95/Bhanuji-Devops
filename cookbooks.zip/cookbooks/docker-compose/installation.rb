#
# Cookbook Name:: docker_compose
# Recipe:: installation
#
# Copyright (c) 2016 Sebastian Boschert, All Rights Reserved.


#command_path = "/usr/local/bin/docker-compose"
#install_url =  "https://github.com/docker/compose/releases/download/1.23.0-rc3/docker-compose-Linux-x86_64"

apt_package "docker-compose" do
 action :install
end
