#
# Cookbook Name:: bulkinstall
# Recipe:: default
#
# Copyright 2018, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

execute "Update" do
	command "apt-get update"
end
apt_package "npm" do
	action :install
end
	
apt_package "openssl" do
	action [:install, :upgrade]
end

apt_package "git-core" do
	action :install
end
execute "config user" do
	command "git config --global user.name 'bhanuji95'"
end
execute "config email" do
	command "git config --global user.email 'bhanujijayanthi@gmail.com'"
end
