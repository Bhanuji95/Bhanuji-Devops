#
# Cookbook Name:: docker-apache
# Recipe:: default
#
# Copyright 2018, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute


# Provision Compose file
cookbook_file '/root/docker-compose.yml' do
  action :nothing
  source 'docker-compose.yml'
  notifies :up, 'docker_compose_application[apache]', :delayed
end

# Provision Compose application
docker_compose_application 'apache' do
  action :up
  compose_files [ '/root/docker-compose.yml' ]
end

#Copy index file
execute "index" do
 command "docker cp /root/Bhanuji-Devops/index.html apache:/var/www/html"
end
