#
# Cookbook Name:: nodejs
# Recipe:: default
#
# Copyright 2018, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

execute "Update" do
	command "apt-get update"
end

execute "install" do
	command "apt-get install curl python-software-properties -y"
end

apt_package "nodejs-legacy" do
	action :install
end

apt_package "nodejs" do
	action :install
end	
